package servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorSockets {

	public static void main(String[] args) throws IOException {
		ServerSocket serv=new ServerSocket(9000);
		while(true) {
			System.out.println("esperando conexiones...");
			Socket sc=serv.accept();
			System.out.println("aceptada ");
			new HiloCliente(sc).start();
		}

	}

}
