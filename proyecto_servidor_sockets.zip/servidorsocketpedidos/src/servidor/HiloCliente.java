package servidor;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import beans.Pedido;
import modelo.DaoPedidos;

public class HiloCliente extends Thread {
	Socket sc;
	

	public HiloCliente(Socket sc) {
		super();
		this.sc = sc;
	}


	@Override
	public void run() {
		DaoPedidos dao=new DaoPedidos();
		List<Pedido> pedidos=dao.obtenerPedidos();
		JSONArray array=new JSONArray();
		for(Pedido p:pedidos) {
			JSONObject ob=new JSONObject();
			ob.put("producto", p.getProducto());
			ob.put("seccion", p.getCategoria());
			ob.put("precio", p.getPrecio());
			array.add(ob);
		}
		PrintStream ps;
		try {
			ps = new PrintStream(sc.getOutputStream());
			ps.println(array.toJSONString());
			ps.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
