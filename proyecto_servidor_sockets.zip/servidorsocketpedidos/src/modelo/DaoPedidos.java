package modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import beans.Pedido;

public class DaoPedidos {
	
	private Connection obtenerConexion() throws SQLException {
		Connection cn=null;
		try {
			Context ct=new InitialContext();	
			//via referencia
			DataSource ds=(DataSource)ct.lookup("java:comp/env/refalmacen");
			//acceso directo al recurso
			//DataSource ds=(DataSource)ct.lookup("jdbc/almacends");
			cn=ds.getConnection();
		}catch(NamingException ex) {
			ex.printStackTrace();
		}
		return cn;
	}
	
	public void altaPedido(String producto, double precio, String categoria) {
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/almacen","root","root");){
			/*String sql="Insert into pedidos (producto,precio,categoria) values('"+producto+"',"+precio+",'"+categoria+"')";
			Statement st=con.createStatement();
			st.execute(sql);*/
			String sql="Insert into pedidos (producto,precio,categoria) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, producto);
			ps.setDouble(2, precio);
			ps.setString(3, categoria);
			ps.execute();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	public List<Pedido> obtenerPedidos(){
		List<Pedido> pedidos=new ArrayList<>();
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/almacen","root","root");){
			String sql="select * from pedidos";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				Pedido p=new Pedido(rs.getInt("idPedido"),rs.getString("producto"),rs.getDouble("precio"),rs.getString("categoria"));
				pedidos.add(p);
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return pedidos;
	}
	public void eliminarPedido(int idPedido) {

		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/almacen","root","root");){
			/*String sql="Insert into pedidos (producto,precio,categoria) values('"+producto+"',"+precio+",'"+categoria+"')";
			Statement st=con.createStatement();
			st.execute(sql);*/
			String sql="delete from pedidos where idPedido=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, idPedido);
			
			ps.execute();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public List<Pedido> recuperarPedidosCategoria(String categoria){
		List<Pedido> pedidos=new ArrayList<>();
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/almacen","root","root");){
			String proc="{call buscaPedidos(?,?)}";
			CallableStatement pc=con.prepareCall(proc);
			//registramos par�metro de salida
			pc.registerOutParameter(2, Types.INTEGER);
			pc.setString(1, categoria);
			ResultSet rs=pc.executeQuery();
			while(rs.next()) {
				Pedido p=new Pedido(rs.getInt("idPedido"),rs.getString("producto"),rs.getDouble("precio"),rs.getString("categoria"));
				pedidos.add(p);
			}
			System.out.println(pc.getInt(2));
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return pedidos;
	}
}
